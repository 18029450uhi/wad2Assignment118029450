import React, {useEffect, useRef} from 'react';

function IWTSC() {

    return (
        <div>
            <iframe
                src="http://localhost:3000"
                title="IWTSC"
                style={{width: '100%', height: '100vh'}}
            />
        </div>
    );
}

export default IWTSC;

